$('.one').on('click', function(){
  $(this).addClass('up'); 
}) 
$('.two').on('click', function(){
  $(this).addClass('down'); 
})
$('.three').on('click', function(){
  $(this).addClass('right'); 
})
$('.four').on('click', function(){
  $(this).addClass('left'); 
})
$('.five').on('click', function(){
  $(this).addClass('up'); 
})
$('.six').on('click', function(){
  $(this).addClass('down'); 
})